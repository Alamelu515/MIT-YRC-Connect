package mityrc.user.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/AddBlood")
public class AddBlood extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String patientName = request.getParameter("patientName");
		int patientAge = Integer.parseInt(request.getParameter("patientAge"));
		String patientGender = request.getParameter("patientGender");
		String bloodGroup = request.getParameter("bloodGroup");
		int numUnits = Integer.parseInt(request.getParameter("numUnits"));
		String location = request.getParameter("location");
		String applicantContact = request.getParameter("applicantContact");
		String applicantName = request.getParameter("applicantName");
		String additionalInfo = request.getParameter("additionalInfo");
		Connection con = null;
		// Establishing the database connection and executing the query
		try {
			// Step 1: Initialize the database connection
			con = DatabaseCon.initialiseDB();

			// Disable auto-commit for transaction management
			con.setAutoCommit(false);

			// Step 2: SQL query to insert data into the 'blood' table
			String ins1 = "INSERT INTO blood (patient_name, patient_age, patient_gender, blood_group, num_units, location, applicant_contact, applicant_name, additional_info) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement st1 = con.prepareStatement(ins1, PreparedStatement.RETURN_GENERATED_KEYS);

			// Set the parameters for the prepared statement
			st1.setString(1, patientName);
			st1.setInt(2, patientAge);
			st1.setString(3, patientGender);
			st1.setString(4, bloodGroup);
			st1.setInt(5, numUnits);
			st1.setString(6, location);
			st1.setString(7, applicantContact);
			st1.setString(8, applicantName);
			st1.setString(9, additionalInfo);

			// Execute the insert operation
			int rowsAffected = st1.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Record inserted into 'blood' table successfully.");

				// Retrieve the auto-generated 'request_id'
				ResultSet generatedKeys = st1.getGeneratedKeys();
				if (generatedKeys.next()) {
					int requestId = generatedKeys.getInt(1);

					// Step 3: Insert the initial status into the 'blood_status' table
					String ins2 = "INSERT INTO blood_status (request_id, status) VALUES (?, ?)";
					PreparedStatement st2 = con.prepareStatement(ins2);

					st2.setInt(1, requestId);
					st2.setString(2, "Pending");

					// Execute the second insert operation
					int statusRowsAffected = st2.executeUpdate();

					if (statusRowsAffected > 0) {
						System.out.println("Initial status inserted into 'blood_status' table successfully.");
					} else {
						System.out.println("Failed to insert initial status into 'blood_status' table.");
						con.rollback(); // Rollback transaction if the second insert fails
						return;
					}
				} else {
					System.out.println("Failed to retrieve generated 'request_id'.");
					con.rollback(); // Rollback transaction if the request_id cannot be retrieved
					return;
				}
			} else {
				System.out.println("Record insertion into 'blood' table failed.");
				con.rollback(); // Rollback transaction if the first insert fails
				return;
			}

			// Commit the transaction
			con.commit();
			System.out.println("Transaction committed successfully.");

		} catch (Exception e) {
			e.printStackTrace();

			// Rollback transaction in case of any exception
			try {
				if (con != null) {
					con.rollback();
					System.out.println("Transaction rolled back due to an error.");
				}
			} catch (Exception rollbackEx) {
				rollbackEx.printStackTrace();
			}
		} finally {
			try {
				if (con != null) {
					// Re-enable auto-commit before closing the connection
					con.setAutoCommit(true);
					con.close();
				}
			} catch (Exception closeEx) {
				closeEx.printStackTrace();
			}
		}
		response.sendRedirect("blood.jsp");
	}
}
